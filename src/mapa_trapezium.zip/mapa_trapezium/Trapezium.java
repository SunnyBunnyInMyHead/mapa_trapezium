package mapa_trapezium;

public class Trapezium {
	private Point nearestMain, nearestAdd, furtherMain, furtherAdd;
	private double area = 0.0;

	public Trapezium(Point nearestMain, Point nearestAdd, Point furtherMain, Point furtherAdd) {
		this.nearestMain = nearestMain;
		this.nearestAdd = nearestAdd;
		this.furtherMain = furtherMain;
		this.furtherAdd = furtherAdd;
		if (nearestMain != null && nearestAdd != null && furtherMain != null && furtherAdd != null) {
			area = calcArea(nearestMain, nearestAdd, furtherMain, furtherAdd);
		}

	}

	public double getArea() {
		return area;
	}

	private double calcArea(double sideA, double sideB, double sideC, double sideD) {
		double p = (sideA + sideB + sideC + sideD) / 2;
		return Math.sqrt((p - sideA) * (p - sideB) * (p - sideC) * (p - sideD));

	}

	private double calcArea(Point nearestMain, Point nearestAdd, Point furtherMain, Point furtherAdd) {
		double sideA, sideB, sideC, sideD;
		sideA = Utils.getDist(nearestMain, furtherAdd);
		sideB = Utils.getDist(nearestMain, nearestAdd);
		sideC = Utils.getDist(nearestAdd, furtherMain);
		sideD = Utils.getDist(furtherMain, furtherAdd);
		return calcArea(sideA, sideB, sideC, sideD);
	}

	public Point[] getPoints() {
		return new Point[] { nearestMain, nearestAdd, furtherMain, furtherAdd };
	}

	public Line getNearLine() {
		return Utils.createLine(nearestMain, nearestAdd);
	}

	public Line getFurtherLine() {
		return Utils.createLine(furtherMain, furtherAdd);
	}

}
