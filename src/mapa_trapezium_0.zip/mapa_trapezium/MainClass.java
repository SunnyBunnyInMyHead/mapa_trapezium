package mapa_trapezium;

import java.util.ArrayList;

public class MainClass {
	static ArrayList<Point> points = new ArrayList<Point>();

	public static void main(String[] args) {

		/*
		 * //checking if Polygon is Bulging points.add(new Point(5,10));
		 * points.add(new Point(7,7)); points.add(new Point(8,4));
		 * points.add(new Point(3,3)); points.add(new Point(1,8));
		 */
		// points.add(new Point(-5,3));
		// System.out.println(Utils.isPolygonBulging( points.toArray(new
		// Point[points.size()])));

		points.add(new Point(1, 5));
		points.add(new Point(1, 7));
		points.add(new Point(2.5, 7.7));
		points.add(new Point(3.5, 8));
		points.add(new Point(4.2, 7));
		points.add(new Point(5.2, 6.8));
		points.add(new Point(5, 6));
		points.add(new Point(4, 4));
		points.add(new Point(3, 3.8));
		points.add(new Point(2, 3.5));

		// started array
		Point[] pointArr = points.toArray(new Point[points.size()]);
		// show(pointArr);
		// edited array
		pointArr = Utils.addMidlePoints(pointArr);
		// show(pointArr);

		// System.out.println(Utils.isPolygonBulging(pointArr));
		Point observer = new Point(6, 11);

		Trapezium trapezium = Utils.calculateTrapezium(pointArr, observer);
		show(trapezium.getPoints());

		System.out.println("near dist: " + Utils.getDist(observer, trapezium.getNearLine()));

		System.out.println("further dist: " + Utils.getDist(observer, trapezium.getFurtherLine()));

	}

	public static void show(Point[] points) {
		System.out.println("x");
		for (Point point : points) {
			System.out.println(point.getX());
		}
		System.out.println("y");
		for (Point point : points) {
			System.out.println(point.getY());
		}
		System.out.println("");

	}
}
